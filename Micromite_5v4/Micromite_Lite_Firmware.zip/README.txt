This is a cut down version of MMBasic for the 28-pin and 44-pin 
standard Micromite.  

With large and graphical intensive programs you can easily run out of 
program memory, especially when you need to embed large fonts.  This
version removes non essential features from MMBasic resulting in
more free flash for programs.  The result is a free flash of 74K 
(25% more than the standard version). 

The features removed are:
- The editor (EDIT command).
- TEMPR, KEYPAD, LCD and RTC commands
- SELECT CASE
- The MEMORY command now just reports the amount of free flash

All these features can be implemented some other way (some in BASIC 
code). All other MMBasic features are unchanged as described in the 
Micromite User Manual.

Note that because programs loaded via AUTOSAVE and XMODEM are 
buffered in RAM you are still limited to loading 50K at a time. But 
you can always load the components (especially fonts) in stages and 
save them to the LIBRARY in stages.

Geoff Graham
projects@geoffg.net
